document.addEventListener('DOMContentLoaded', function() {
  /*
    var xmlhttp = new XMLHttpRequest();
    var url = '/icons'
    xmlhttp.open('GET', url, false);
    xmlhttp.send();
    document.body.insertBefore(xmlhttp.responseXML.firstChild, document.body.firstChild)
  */
});
